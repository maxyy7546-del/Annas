const API = "http://127.0.0.1:5000/api";

async function loadJobs() {
  const jobs = await fetch(`${API}/jobs`).then(r => r.json());
  document.getElementById("jobList").innerHTML = jobs.map(job => `
    <article class="card">
      <h3>${job.title}</h3>
      <p><b>Company:</b> ${job.company}</p>
      <p><b>Location:</b> ${job.location}</p>
      <p><b>Eligibility:</b> ${job.eligibility}</p>
      <p><b>Rounds:</b> ${job.rounds.join(" → ")}</p>
    </article>
  `).join("");
}

async function loadResources() {
  const items = await fetch(`${API}/resources`).then(r => r.json());
  document.getElementById("resourceList").innerHTML = items.map(item => `
    <article class="card">
      <h3>${item.title}</h3>
      <p>Category: ${item.category}</p>
    </article>
  `).join("");
}

async function loadQuestion() {
  const items = await fetch(`${API}/mock-interview`).then(r => r.json());
  document.getElementById("question").textContent = items[0].question;
}

async function evaluateAnswer() {
  const answer = document.getElementById("answer").value;
  const result = await fetch(`${API}/mock-interview/evaluate`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({answer})
  }).then(r => r.json());

  document.getElementById("feedback").innerHTML =
    `<b>Score: ${result.score}/100</b><br>${result.feedback}`;
}

async function loadGrooming() {
  const data = await fetch(`${API}/grooming`).then(r => r.json());
  const sections = [
    ["Professional Clothing", data.clothing],
    ["Colour Combinations", data.colours],
    ["Personal Grooming", data.grooming],
    ["Body Language", data.body_language]
  ];

  document.getElementById("groomingList").innerHTML = sections.map(([title, list]) => `
    <article class="card">
      <h3>${title}</h3>
      <ul>${list.map(x => `<li>${x}</li>`).join("")}</ul>
    </article>
  `).join("");
}

loadJobs();
loadResources();
loadQuestion();
loadGrooming();
