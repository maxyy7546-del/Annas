# Microsoft Career Guide App

A simple full-stack prototype based on the IEEE-style abstract provided by the user.

## Features
- Job vacancies and eligibility information
- Application procedure guidance
- Interview-round guidance
- Learning resources: coding, aptitude, communication, English, problem solving
- Mock interview practice
- Dressing sense and grooming guidance
- REST API backend
- Responsive frontend

## Run
1. Install Python 3.10+.
2. Open a terminal in the `backend` folder.
3. Run:
   `python app.py`
4. Open:
   `http://127.0.0.1:5000`

The project is a prototype and does not connect to Microsoft's real recruitment system.
