from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

app = Flask(__name__)
CORS(app)

jobs = [
    {
        "id": 1,
        "title": "Software Engineer",
        "company": "Microsoft",
        "eligibility": "Degree in Computer Science or related field; relevant programming skills.",
        "location": "Hyderabad",
        "rounds": ["Online Assessment", "Technical Interview", "Behavioral Interview"]
    },
    {
        "id": 2,
        "title": "Software Engineer Intern",
        "company": "Microsoft",
        "eligibility": "Students or recent graduates with programming and problem-solving skills.",
        "location": "India",
        "rounds": ["Coding Assessment", "Technical Interview", "Final Discussion"]
    }
]

questions = [
    {
        "id": 1,
        "question": "Tell me about yourself.",
        "skill": "Communication"
    },
    {
        "id": 2,
        "question": "Explain the difference between an array and a linked list.",
        "skill": "Technical"
    },
    {
        "id": 3,
        "question": "Describe a problem you solved using programming.",
        "skill": "Problem Solving"
    },
    {
        "id": 4,
        "question": "Why do you want to work in software development?",
        "skill": "HR"
    },
    {
        "id": 5,
        "question": "Tell me about yourself.",
        "skill": "Communication"
    },
    {
        "id": 6,
        "question": "Why do you want to work in software development?",
        "skill": "HR"
    },
    {
        "id": 7,
        "question": "What is the difference between C and Python?",
        "skill": "Technical"
    },
    {
        "id": 8,
        "question": "What is HTML?",
        "skill": "Web Development"
    },
    {
        "id": 9,
        "question": "What is CSS?",
        "skill": "Web Development"
    },
    {
        "id": 10,
        "question": "What is JavaScript?",
        "skill": "Web Development"
    },
    {
        "id": 11,
        "question": "What is an API?",
        "skill": "Backend"
    },
    {
        "id": 12,
        "question": "Describe a project you worked on.",
        "skill": "Project"
    }
]

resources = [
    {"id": 1, "title": "C Programming Basics", "category": "Coding"},
    {"id": 2, "title": "Aptitude Practice", "category": "Aptitude"},
    {"id": 3, "title": "English Communication", "category": "English"},
    {"id": 4, "title": "Problem-Solving Practice", "category": "Problem Solving"},
    {"id": 5, "title": "Interview Communication", "category": "Communication"}
]

@app.get("/api/jobs")
def get_jobs():
    return jsonify(jobs)

@app.get("/api/jobs/<int:job_id>")
def get_job(job_id):
    job = next((j for j in jobs if j["id"] == job_id), None)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job)

@app.get("/api/resources")
def get_resources():
    category = request.args.get("category")
    if category:
        return jsonify([r for r in resources if r["category"].lower() == category.lower()])
    return jsonify(resources)

@app.get("/api/mock-interview")
def get_questions():
    return jsonify(questions)

@app.post("/api/mock-interview/evaluate")
def evaluate_answer():
    data = request.get_json(silent=True) or {}
    answer = str(data.get("answer", "")).strip()

    if not answer:
        return jsonify({"score": 0, "feedback": "Please enter an answer."})

    length_score = min(len(answer.split()) * 2, 60)
    structure_bonus = 40 if any(word in answer.lower() for word in
                                 ["because", "example", "experience", "learned"]) else 20
    score = min(length_score + structure_bonus, 100)

    return jsonify({
        "score": score,
        "feedback": (
            "Good start. Try to make your answer specific, structured, and supported "
            "with a short example."
        )
    })

@app.get("/api/grooming")
def grooming():
    return jsonify({
        "clothing": ["Formal shirt or professional top", "Clean formal trousers", "Formal shoes"],
        "colours": ["Neutral combinations", "Simple professional colours"],
        "grooming": ["Neat hair", "Clean appearance", "Organized documents"],
        "body_language": ["Maintain comfortable eye contact", "Sit upright", "Use a confident and polite tone"]
    })

@app.get("/")
def home():
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.get("/style.css")
def serve_css():
    return send_from_directory(FRONTEND_DIR, "style.css")

@app.get("/script.js")
def serve_js():
    return send_from_directory(FRONTEND_DIR, "script.js")

@app.get("/api")
def api_root():
    return jsonify({"message": "Microsoft Career Guide API is running"})

if __name__ == "__main__":
    app.run(debug=True)
